import streamlit as st, json
from pathlib import Path
from datetime import datetime
from ui import inject_css, sidebar_brand, badge, page_header
st.set_page_config(page_title='QuickSite',page_icon='⚡',layout='wide',initial_sidebar_state='expanded'); inject_css()
ROOT=Path(__file__).parent; DATA=ROOT/'data'; DATA.mkdir(exist_ok=True)
def load(name,default):
 p=DATA/name
 if p.exists():
  try:return json.loads(p.read_text(encoding='utf8'))
  except:return default
 return default
def save():
 (DATA/'cards.json').write_text(json.dumps(st.session_state.cards,ensure_ascii=False,indent=2),encoding='utf8'); (DATA/'history.json').write_text(json.dumps(st.session_state.history,ensure_ascii=False,indent=2),encoding='utf8')
DEFAULT_CARDS=[{'id':1,'name':'Datos fijos','category':'General','description':'Información de empresa, público objetivo y datos que no deben inventarse.','content':'Nuestra empresa crea contenido digital para negocios y marcas. Público objetivo: emprendedores, pymes y profesionales del marketing. Tono cercano, claro y profesional. No inventar precios, horarios ni plazos.','active':True},{'id':2,'name':'Estilo','category':'Estilo','description':'Guía de estilo, tono, estructura y formato.','content':'Usar castellano de España, frases claras y párrafos breves. Estructura: título atractivo, introducción, desarrollo con H2/H3 y conclusión con llamada a la acción.','active':True},{'id':3,'name':'Reglas','category':'SEO','description':'Buenas prácticas y restricciones de contenido.','content':'No inventar datos ni fuentes. Incluir la palabra clave de forma natural. Siempre crear borrador, nunca publicar automáticamente.','active':True},{'id':4,'name':'Tema','category':'Contenido','description':'Temas y enfoques recurrentes.','content':'Priorizar guías prácticas, tutoriales y contenido útil para pequeñas empresas.','active':False}]
DEFAULT_HISTORY=[{'id':1,'date':'25 abr 2025 · 14:32','title':'Cómo crear una página web rápida y profesional con WordPress','keywords':'wordpress, página web, web rápida, diseño web','status':'Generada','content':'Crear una página web ya no es solo cosa de grandes empresas. Con WordPress puedes tener tu propio sitio web de forma rápida, sencilla y profesional.','meta':'Descubre paso a paso cómo crear una página web con WordPress de forma rápida y profesional.'},{'id':2,'date':'24 abr 2025 · 16:17','title':'Los mejores plugins para WordPress en 2025','keywords':'plugins, wordpress, seo, mejores plugins','status':'Enviada como borrador','content':'Elegir plugins adecuados ayuda a mejorar la seguridad, el rendimiento y el SEO de tu web.','meta':'Guía práctica para elegir plugins de WordPress.'},{'id':3,'date':'22 abr 2025 · 11:03','title':'Guía completa de SEO para principiantes','keywords':'seo, posicionamiento, wordpress, marketing digital','status':'Generada','content':'El SEO ayuda a que una página aparezca en los resultados de búsqueda. Empieza por comprender la intención de búsqueda y crear contenido útil.','meta':'Aprende los fundamentos del SEO paso a paso.'}]
if 'cards' not in st.session_state: st.session_state.cards=load('cards.json',DEFAULT_CARDS)
if 'history' not in st.session_state: st.session_state.history=load('history.json',DEFAULT_HISTORY)
if 'page' not in st.session_state: st.session_state.page='Generador'
if 'draft' not in st.session_state: st.session_state.draft=None
if 'messages' not in st.session_state: st.session_state.messages=[]
with st.sidebar:
 sidebar_brand(); st.markdown('<div class="side-nav-label">ESPACIO DE TRABAJO</div>',unsafe_allow_html=True)
 for icon,label in [('⌂','Inicio'),('✦','Generador'),('▤','Fichas'),('◷','Historial'),('⚙','Ajustes')]:
  if st.button(f'{icon}   {label}',key='nav_'+label,use_container_width=True,type='primary' if st.session_state.page==label else 'secondary'): st.session_state.page=label; st.rerun()
 st.markdown('---'); st.markdown('<div class="side-nav-label">FICHAS ACTIVAS</div>',unsafe_allow_html=True)
 active=[c for c in st.session_state.cards if c['active']]; st.caption(f'{len(active)}/5 fichas activas')
 for c in active: st.markdown(f'<div class="active-card">▤ &nbsp; {c["name"]}<span class="toggle-dot">●</span></div>',unsafe_allow_html=True)
 st.markdown('<div class="sidebar-footer"><span class="bolt">ϟ</span><div><b>Tu plan</b><br><span>Prototipo local</span></div></div>',unsafe_allow_html=True)
page=st.session_state.page
if page=='Inicio':
 page_header('Panel de control','Bienvenido a QuickSite. Genera, revisa y organiza tus artículos.')
 a,b,c=st.columns(3); a.metric('Artículos en historial',len(st.session_state.history)); b.metric('Fichas activas',f'{len(active)}/5'); c.metric('Borradores simulados',sum(h['status']=='Enviada como borrador' for h in st.session_state.history))
 st.markdown('### Accesos rápidos'); x,y,z=st.columns(3)
 for col,title,desc,target in [(x,'Generar un artículo','Define tema, tono y longitud.','Generador'),(y,'Fichas de contexto','Administra información recurrente.','Fichas'),(z,'Historial','Consulta artículos de prueba.','Historial')]:
  with col:
   st.markdown(f'<div class="feature-card"><div class="feature-icon">✦</div><h3>{title}</h3><p>{desc}</p></div>',unsafe_allow_html=True)
   if st.button('Abrir →',key='go'+target,use_container_width=True):st.session_state.page=target;st.rerun()
 st.info('Modo demostración: no hay conexión con Ollama, WordPress ni servicios externos.')
elif page=='Generador':
 st.markdown('<div class="eyebrow">QUICKSITE / GENERADOR</div>',unsafe_allow_html=True); st.title('Genera un artículo para tu blog'); st.markdown('Escribe un tema y configura el borrador que preparará QuickSite.')
 left,right=st.columns([1.05,.95],gap='large')
 with left:
  t1,t2=st.tabs(['✦  Construcción','☷  Chat'])
  with t1:
   with st.form('generate'):
    topic=st.text_input('Tema o idea del artículo *',placeholder='Ej.: Beneficios del marketing de contenidos para pequeñas empresas',max_chars=200)
    tone=st.radio('Tono de voz',['Profesional','Conversacional','Informativo','Persuasivo','Creativo'],horizontal=True)
    length=st.radio('Longitud del artículo',['Corto (300–600 palabras)','Medio (600–1200 palabras)','Largo (1200+ palabras)'],index=1)
    keywords=st.text_input('Palabras clave (opcional)',placeholder='wordpress, SEO, marketing digital',max_chars=100)
    with st.expander('Opciones avanzadas'):
     category=st.selectbox('Categoría',['Guía','Tecnología','Marketing','Tutorial','Noticias']); st.selectbox('Idioma',['Castellano (España)']); extra=st.text_input('Instrucciones adicionales',placeholder='Incluye ejemplos, pasos...')
    go=st.form_submit_button('✦  Generar artículo de prueba',type='primary',use_container_width=True)
   if go:
    if not topic.strip():st.error('Escribe un tema antes de generar el artículo.')
    else:
     title=topic.strip().capitalize(); title=title if title.lower().startswith(('cómo','guía','qué','por qué')) else title+': guía práctica'; kw=keywords.strip() or topic.lower()
     intro=f'En esta guía sobre {topic.strip().lower()}, repasamos los puntos clave y recomendaciones prácticas para empezar.'
     content=f'## ¿Por qué es importante este tema?\n\n{intro}\n\n## Pasos para empezar\n\n1. Define tu objetivo y el público al que quieres dirigirte.\n2. Reúne la información necesaria y comprueba los datos importantes.\n3. Organiza las ideas en una estructura clara.\n4. Aplica las recomendaciones y revisa los resultados.\n\n## Consejos prácticos\n\nUtiliza ejemplos relevantes y adapta cada recomendación a tu situación. Antes de publicar, revisa cifras y datos específicos.\n\n## Conclusión\n\nCon una planificación sencilla y una revisión cuidadosa, puedes avanzar paso a paso.'
     d={'title':title,'topic':topic,'tone':tone,'length':length,'keywords':kw,'category':category,'meta':f'Descubre {topic.lower()} con esta guía práctica y consejos claros.','content':content}; st.session_state.draft=d
     st.session_state.history.insert(0,{'id':max([h.get('id',0) for h in st.session_state.history]+[0])+1,'date':datetime.now().strftime('%d %b %Y · %H:%M'),'title':title,'keywords':kw,'status':'Generada','content':intro,'meta':d['meta']}); save(); st.success('Artículo de prueba generado y guardado en el historial.')
  with t2:
   st.markdown('### Chat con QuickSite AI'); st.caption('Conversación simulada. No se consulta ningún modelo.')
   for msg in st.session_state.messages:
    with st.chat_message(msg['role'],avatar='⚡' if msg['role']=='assistant' else '●'):st.markdown(msg['content'])
   with st.form('chat',clear_on_submit=True): prompt=st.text_input('Mensaje',placeholder='Pide un artículo o una mejora...'); send=st.form_submit_button('Enviar',type='primary')
   if send and prompt.strip():
    st.session_state.messages.extend([{'role':'user','content':prompt.strip()},{'role':'assistant','content':'¡Entendido! Esta es una respuesta de prueba. En la versión conectada usaría las fichas activas para ayudarte con: **'+prompt.strip()+'**.'}]);st.rerun()
 with right:
  st.markdown('<div class="preview-head"><span>◉ &nbsp; Previsualización</span><span class="preview-chip">BORRADOR</span></div>',unsafe_allow_html=True); d=st.session_state.draft
  if d:
   st.markdown(f'<div class="article-preview"><span class="category-pill">{d["category"]}</span><h2>{d["title"]}</h2><div class="article-meta">▦ Hoy &nbsp; · &nbsp; ◷ 6 min de lectura &nbsp; · &nbsp; QuickSite</div><p>{d["meta"]}</p><hr><p>{d["content"].replace(chr(10)+chr(10),"</p><p>").replace(chr(10),"<br>")}</p></div>',unsafe_allow_html=True)
   st.download_button('Descargar borrador .md',f'# {d["title"]}\n\n{d["meta"]}\n\n{d["content"]}',file_name='borrador_quicksite.md',mime='text/markdown',use_container_width=True)
   if st.button('Enviar a WordPress como borrador',type='primary',use_container_width=True):
    for h in st.session_state.history:
     if h['title']==d['title'] and h['status']=='Generada':h['status']='Enviada como borrador';break
    save();st.success('Simulación completada: no se ha contactado con WordPress.')
  else:st.markdown('<div class="empty-preview"><div class="image-placeholder">▧</div><h3>Tu artículo aparecerá aquí</h3><p>Completa el formulario y genera un borrador de prueba.</p><div class="skeleton"></div><div class="skeleton short"></div><div class="skeleton"></div></div>',unsafe_allow_html=True);st.info('El contenido de prueba necesita revisión humana.')
elif page=='Fichas':
 page_header('Fichas de contexto','Guarda información recurrente que orienta los artículos.'); left,right=st.columns([.95,1.05],gap='large');
 with left:
  search=st.text_input('⌕ Buscar fichas...',placeholder='Nombre o descripción')
  for card in st.session_state.cards:
   if search.lower() not in (card['name']+' '+card['description']).lower():continue
   with st.container(border=True):
    st.markdown(f'### {card["name"]}');st.caption(f'{card["category"]} · {card["description"]}');st.markdown(badge('Activa' if card['active'] else 'Inactiva','green' if card['active'] else 'gray'),unsafe_allow_html=True)
    if st.button('Editar ficha',key='edit'+str(card['id']),use_container_width=True):st.session_state.edit_id=card['id'];st.rerun()
  if st.button('＋ Nueva ficha',type='primary',use_container_width=True):
   nid=max([c['id'] for c in st.session_state.cards]+[0])+1;st.session_state.cards.append({'id':nid,'name':'Nueva ficha','category':'General','description':'Nueva ficha de contexto','content':'','active':False});st.session_state.edit_id=nid;save();st.rerun()
 with right:
  cid=st.session_state.get('edit_id',st.session_state.cards[0]['id'] if st.session_state.cards else None); card=next((c for c in st.session_state.cards if c['id']==cid),None)
  if card:
   st.markdown('### Editar ficha')
   with st.form('edit_card'):
    name=st.text_input('Nombre de la ficha',card['name'],max_chars=50); cats=['General','Estilo','SEO','Contenido'];cat=st.selectbox('Categoría',cats,index=cats.index(card['category']) if card['category'] in cats else 0);desc=st.text_input('Descripción',card['description']);content=st.text_area('Contenido de la ficha',card['content'],height=250,max_chars=2000);on=st.toggle('Activa',value=card['active']);save_btn=st.form_submit_button('Guardar cambios',type='primary',use_container_width=True)
   if save_btn:card.update({'name':name.strip() or 'Ficha sin nombre','category':cat,'description':desc,'content':content,'active':on});save();st.success('Ficha guardada en local.');st.rerun()
   if st.button('Eliminar ficha',use_container_width=True):st.session_state.cards=[c for c in st.session_state.cards if c['id']!=cid];st.session_state.pop('edit_id',None);save();st.rerun()
elif page=='Historial':
 page_header('Historial','Consulta y gestiona los artículos que has generado con QuickSite.');a,b,c=st.columns([1.4,.8,.8]);q=a.text_input('Buscar por título o palabra clave...',placeholder='Título o palabra clave');status=b.selectbox('Estado',['Todos los estados','Generada','Enviada como borrador']);period=c.selectbox('Periodo',['Todo el historial','Últimos 30 días','Últimos 7 días']);items=[h for h in st.session_state.history if q.lower() in (h['title']+' '+h['keywords']).lower() and (status=='Todos los estados' or h['status']==status)];st.caption(f'{len(items)} artículos')
 for h in items:
  with st.expander(f'{h["date"]}   ·   {h["title"]}   ·   {h["status"]}'):
   l,r=st.columns([.8,.2]);l.markdown('### '+h['title']);l.write(h.get('content',''));l.caption('Palabras clave: '+h.get('keywords',''));l.caption('Meta descripción: '+h.get('meta',''))
   if r.button('Abrir',key='open'+str(h['id']),use_container_width=True):st.session_state.draft={'title':h['title'],'topic':h['title'],'tone':'Profesional','length':'Medio (600–1200 palabras)','keywords':h['keywords'],'category':'Guía','meta':h.get('meta',''),'content':h.get('content','')};st.session_state.page='Generador';st.rerun()
   if r.button('Reenviar (simular)',key='resend'+str(h['id']),use_container_width=True):st.toast('Acción de prueba: no se ha enviado nada a WordPress.')
   if r.button('Eliminar',key='del'+str(h['id']),use_container_width=True):st.session_state.history=[x for x in st.session_state.history if x['id']!=h['id']];save();st.rerun()
elif page=='Ajustes':
 page_header('Configuración','Preferencias de la interfaz y estado de las integraciones.');st.markdown('### Apariencia');st.selectbox('Tema',['Oscuro QuickSite'],disabled=True);st.markdown('### Integraciones')
 for name,desc in [('Ollama','Generación de texto mediante un modelo local.'),('WordPress REST API','Envío de artículos únicamente como borradores.'),('Pexels','Imágenes de stock con crédito.')]:
  with st.container(border=True):a,b=st.columns([.8,.2]);a.markdown('**'+name+'**');a.caption(desc);b.markdown(badge('Sin conectar','gray'),unsafe_allow_html=True)
 st.warning('Las integraciones están desactivadas. No se realizan peticiones externas.');st.caption('Las fichas y el historial se guardan en data/.')
 if st.button('Restablecer datos de demostración'):
  st.session_state.cards=DEFAULT_CARDS.copy();st.session_state.history=DEFAULT_HISTORY.copy();save();st.success('Datos de demostración restablecidos.');st.rerun()
