# QuickSite — interfaz Streamlit (prototipo sin conexiones)

Interfaz de demostración basada en las referencias visuales y en `contextoia.md`.

## Ejecutar en Windows
1. Instala Python 3.10 o superior.
2. Descomprime el ZIP y abre una terminal dentro de `quicksite_streamlit`.
3. Ejecuta `py -m venv .venv` y después `.venv\Scripts\Activate.ps1`.
4. Instala dependencias: `pip install -r requirements.txt`.
5. Inicia: `streamlit run app.py`.

## Funcionalidades
- Inicio con métricas y accesos rápidos.
- Generador en modo Construcción y Chat simulado.
- Previsualización de artículo, descarga Markdown y simulación de envío como borrador.
- Gestor de fichas: crear, editar, activar/desactivar y eliminar.
- Historial con búsqueda, filtro por estado, abrir artículo, reenvío simulado y eliminación.
- Ajustes e indicador de integraciones sin conectar.

## Sin conexiones externas
No conecta con Ollama, WordPress, Rank Math ni Pexels. Los botones usan mensajes de prueba y acciones locales. El contenido generado es una plantilla de demostración, no IA real. Nunca publica automáticamente. Los datos se guardan en `data/cards.json` y `data/history.json`.
